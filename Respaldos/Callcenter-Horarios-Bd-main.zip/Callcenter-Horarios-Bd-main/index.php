<?php
include 'functions.php';
?>

<?=template_header('Home')?>

<div class="content">
	<h2>Home</h2>
	<p>This is your home page</p>
</div>

<?=template_footer()?>